//
//  TableViewCell.swift
//  Desafio
//
//  Created by Josicleison Elves on 29/04/22.
//

import UIKit

class TableViewCell: UITableViewCell
{
    @IBOutlet weak var storeUsername: UILabel!
    @IBOutlet weak var storePassword: UILabel!
    
    override func awakeFromNib()
    {
        super.awakeFromNib()
        
        storeUsername.text = "Josicleison"
        storePassword.text = "123"
    }

    override func setSelected(_ selected: Bool, animated: Bool)
    {
        super.setSelected(selected, animated: animated)
    }
    
}

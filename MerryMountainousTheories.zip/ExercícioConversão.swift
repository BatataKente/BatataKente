import Foundation

var a,b:Int
var c:Double=0.1

a=3
b=5

var resto=Double(a%b) + c

print(resto)
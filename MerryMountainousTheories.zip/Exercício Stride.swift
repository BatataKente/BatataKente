print("We're starting in...")

// Edit the range 1...3 in the loop to use stride() 🏁
for num in stride(from:3,to:0,by:-1)
{
  print(num)
}

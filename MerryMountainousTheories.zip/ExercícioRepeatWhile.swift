import Foundation

for numbero in 1...100 {
  if numbero%2==1
  {
    print("\(numbero) is odd")
  }
  else
  {
    print("\(numbero) is even")
  }
}


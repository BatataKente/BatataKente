import Foundation

var text1:String
text1="Minha idade é"

var text2:String="e meu peso é"

var idade:UInt=89

var peso:Float=55.5

let text=text1+" \(idade) anos "+text2+" \(peso) kilos"

print(text)
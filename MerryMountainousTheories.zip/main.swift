import Foundation

func linha()
{
  print("\n---------------------------------\n")
}

//DESIGN PATTERN: SINGLETON


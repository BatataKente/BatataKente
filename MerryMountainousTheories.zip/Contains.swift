import Foundation

var email = "Josi@farofa.com"

if email.contains("0")||email.contains("1")||email.contains("2")||email.contains("3")||email.contains("4")||email.contains("5")||email.contains("6")||email.contains("7")||email.contains("8")||email.contains("9")
{
  print("O email é válido")
}
else
{
  print("O email não é válido")
}